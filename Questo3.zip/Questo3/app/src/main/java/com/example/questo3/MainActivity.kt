package com.example.questo3

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets



                private lateinit var edTempoGasto: EditText
                private lateinit var edVelocidadeMedia: EditText
                private lateinit var edMedia: EditText
                private lateinit var tvResultado: TextView
                private lateinit var btCalcular: Button

                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContentView(R.layout.activity_main)

                    edTempoGasto = findViewById(R.id.edTempoGasto)
                    edVelocidadeMedia = findViewById(R.id.edVelocidadeMedia)
                    edMedia = findViewById(R.id.edMedia)
                    tvResultado = findViewById(R.id.tvResultado)
                    btCalcular = findViewById(R.id.btCalcular)

                    btCalcular.setOnClickListener {
                        calculateFuel()
                    }
                }

                private fun calculateFuel() {
                    val tempoGasto = edTempoGasto.text.toString().toDoubleOrNull() ?: 0.0
                    val velocidadeMedia = edVelocidadeMedia.text.toString().toDoubleOrNull() ?: 0.0
                    val media = edMedia.text.toString().toDoubleOrNull() ?: 0.0

                    val distancia = tempoGasto * velocidadeMedia
                    val litrosUsados = if (media != 0.0) distancia / media else 0.0

                    tvResultado.text = "Litros Usados: %.2f".format(litrosUsados)
                }
            }



        }
    }
}