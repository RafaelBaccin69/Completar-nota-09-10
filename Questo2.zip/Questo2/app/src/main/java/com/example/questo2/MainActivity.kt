package com.example.questo2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

                private lateinit var edLarguraA: EditText
                private lateinit var edLarguraB: EditText
                private lateinit var edAlturaA: EditText
                private lateinit var edAlturaB: EditText
                private lateinit var tvArea: TextView
                private lateinit var tvPerimetro: TextView
                private lateinit var btCalcular: Button

                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContentView(R.layout.activity_main)

                    edLarguraA = findViewById(R.id.edLarguraA)
                    edLarguraB = findViewById(R.id.edLarguraB)
                    edAlturaA = findViewById(R.id.edAlturaA)
                    edAlturaB = findViewById(R.id.edAlturaB)
                    tvArea = findViewById(R.id.tvArea)
                    tvPerimetro = findViewById(R.id.tvPerimetro)
                    btCalcular = findViewById(R.id.btCalcular)

                    btCalcular.setOnClickListener {
                        calculate()
                    }
                }

                private fun calculate() {
                    val larguraA = edLarguraA.text.toString().toDoubleOrNull() ?: 0.0
                    val larguraB = edLarguraB.text.toString().toDoubleOrNull() ?: 0.0
                    val alturaA = edAlturaA.text.toString().toDoubleOrNull() ?: 0.0
                    val alturaB = edAlturaB.text.toString().toDoubleOrNull() ?: 0.0

                    val area = larguraA * alturaA
                    val perimetro = 2 * (larguraA + larguraB + alturaA + alturaB)

                    tvArea.text = "Área: $area"
                    tvPerimetro.text = "Perímetro: $perimetro"
                }
            }

        }

    }
}