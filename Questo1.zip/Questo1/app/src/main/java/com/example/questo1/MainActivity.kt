package com.example.questo1

import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

            <LinearLayout
            xmlns:android="http://schemas.android.com/apk/res/android"
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:orientation="vertical"
            android:padding="10dp"
            android:gravity="center">

            <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Calculadora de Perímetro e Área"
            android:textSize="24sp"
            android:layout_gravity="center"
            android:marginBottom="20dp" />

            <EditText
            android:id="@+id/edLarguraA"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Largura A"
            android:inputType="numberDecimal"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edLarguraB"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Largura B"
            android:inputType="numberDecimal"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edLarguraC"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Largura C"
            android:inputType="numberDecimal"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edLarguraD"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Largura D"
            android:inputType="numberDecimal"
            android:marginBottom="10dp" />

            <TextView
            android:id="@+id/tvPerimetro"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Perímetro"
            android:textSize="18sp"
            android:marginBottom="10dp" />

            <TextView
            android:id="@+id/tvArea"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Área"
            android:textSize="18sp"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edEndereco"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Endereço"
            android:inputType="text"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edBairro"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Bairro"
            android:inputType="text"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edCidade"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Cidade"
            android:inputType="text"
            android:marginBottom="10dp" />

            <EditText
            android:id="@+id/edObservacoes"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Observações"
            android:inputType="text"
            android:marginBottom="20dp" />

            <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center">

            <Button
            android:id="@+id/btCancelar"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Cancelar"
            android:layout_marginEnd="10dp" />

            <Button
            android:id="@+id/btSalvar"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Salvar" />
            </LinearLayout>
            </LinearLayout>
        }
    }
}